When updating the project

- Always review whether the README.md in trickle/notes needs to be updated
- Update README when adding new features, components, or changing project structure
- Keep the README concise and focused on essential information
- Include any important technical decisions or changes in the README